﻿using System;
using System.Web.UI;

namespace Demo
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}